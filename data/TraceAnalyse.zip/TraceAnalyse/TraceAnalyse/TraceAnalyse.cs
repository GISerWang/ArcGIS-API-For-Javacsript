﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using System.Collections.Specialized;

using System.Runtime.InteropServices;

using ESRI.ArcGIS.esriSystem;
using ESRI.ArcGIS.Server;
using ESRI.ArcGIS.Geometry;
using ESRI.ArcGIS.Geodatabase;
using ESRI.ArcGIS.Carto;
using ESRI.ArcGIS.SOESupport;


//TODO: sign the project (project properties > signing tab > sign the assembly)
//      this is strongly suggested if the dll will be registered using regasm.exe <your>.dll /codebase


namespace TraceAnalyse
{
    [ComVisible(true)]
    [Guid("d51e0ef1-cf62-4c1d-ba1c-f42d01506e34")]
    [ClassInterface(ClassInterfaceType.None)]
    [ServerObjectExtension("MapServer",//use "MapServer" if SOE extends a Map service and "ImageServer" if it extends an Image service.
        AllCapabilities = "",
        DefaultCapabilities = "",
        Description = "",
        DisplayName = "TraceAnalyse",
        Properties = "",
        SupportsREST = true,
        SupportsSOAP = false)]
    public class TraceAnalyse : IServerObjectExtension, IObjectConstruct, IRESTRequestHandler
    {
        private string soe_name;

        private IPropertySet configProps;
        private IServerObjectHelper serverObjectHelper;
        private ServerLogger logger;
        private IRESTRequestHandler reqHandler;
        private TraceUtils traceutils;
        public TraceAnalyse()
        {
            soe_name = this.GetType().Name;
            logger = new ServerLogger();
            reqHandler = new SoeRestImpl(soe_name, CreateRestSchema()) as IRESTRequestHandler;
        }

        #region IServerObjectExtension Members

        public void Init(IServerObjectHelper pSOH)
        {
            serverObjectHelper = pSOH;
        }

        public void Shutdown()
        {
        }

        #endregion

        #region IObjectConstruct Members

        public void Construct(IPropertySet props)
        {
            configProps = props;
        }

        #endregion

        #region IRESTRequestHandler Members

        public string GetSchema()
        {
            return reqHandler.GetSchema();
        }

        public byte[] HandleRESTRequest(string Capabilities, string resourceName, string operationName, string operationInput, string outputFormat, string requestProperties, out string responseProperties)
        {
            return reqHandler.HandleRESTRequest(Capabilities, resourceName, operationName, operationInput, outputFormat, requestProperties, out responseProperties);
        }

        #endregion

        private RestResource CreateRestSchema()
        {
            RestResource rootRes = new RestResource(soe_name, false, RootResHandler);

            RestOperation sampleOper = new RestOperation("getInfo",
                                                      new string[] { "tol", "type", "listJunctionFlags", "listEdgeFlags", "listJunctionBarrier", "listEdgeBarrier" },
                                                      new string[] { "json" },
                                                      SampleOperHandler);

            rootRes.operations.Add(sampleOper);

            return rootRes;
        }

        private byte[] RootResHandler(NameValueCollection boundVariables, string outputFormat, string requestProperties, out string responseProperties)
        {
            responseProperties = null;

            JsonObject result = new JsonObject();
            result.AddString("hello", "world");

            return Encoding.UTF8.GetBytes(result.ToJson());
        }

        private byte[] SampleOperHandler(NameValueCollection boundVariables,
                                                  JsonObject operationInput,
                                                      string outputFormat,
                                                      string requestProperties,
                                                  out string responseProperties)
        {
            IMapServer3 mapServer = this.GetMapServer();
            IMapServerDataAccess dataAccess = (IMapServerDataAccess)mapServer;
            IFeatureClass featureclass = (IFeatureClass)dataAccess.GetDataSource(mapServer.DefaultMapName, 0);
            IFeatureDataset ds = featureclass.FeatureDataset;
            INetworkCollection2 networkCollection2 = ds as INetworkCollection2;
            IGeometricNetwork geometricNetwork = networkCollection2.get_GeometricNetwork(0);
            traceutils = new TraceUtils(geometricNetwork, serverObjectHelper);
            traceutils.init();
            responseProperties = null;
            object[] listJunctionFlags;
            operationInput.TryGetArray("listJunctionFlags", out listJunctionFlags);
            object[] listEdgeFlags;
            operationInput.TryGetArray("listEdgeFlags", out listEdgeFlags);
            object[] listJunctionBarrier;
            operationInput.TryGetArray("listJunctionBarrier", out listJunctionBarrier);
            object[] listEdgeBarrier;
            operationInput.TryGetArray("listEdgeBarrier", out listEdgeBarrier);
            long? type;
            operationInput.TryGetAsLong("type", out type);
            double? tol;
            operationInput.TryGetAsDouble("tol", out tol);
            List<IPoint> junctionFlags = new List<IPoint>();
            List<IPoint> edgeFlags = new List<IPoint>();
            List<IPoint> junctionBarrier = new List<IPoint>();
            List<IPoint> edgeBarrier = new List<IPoint>();
            foreach (JsonObject jo in listJunctionFlags.Cast<JsonObject>().ToArray())
            {
                IPoint location = Conversion.ToGeometry(jo, esriGeometryType.esriGeometryPoint) as IPoint;
                junctionFlags.Add(location);
            }
            foreach (JsonObject jo in listEdgeFlags.Cast<JsonObject>().ToArray())
            {
                IPoint location = Conversion.ToGeometry(jo, esriGeometryType.esriGeometryPoint) as IPoint;
                edgeFlags.Add(location);
            }
            foreach (JsonObject jo in listJunctionBarrier.Cast<JsonObject>().ToArray())
            {
                IPoint location = Conversion.ToGeometry(jo, esriGeometryType.esriGeometryPoint) as IPoint;
                junctionBarrier.Add(location);
            }
            foreach (JsonObject jo in listEdgeBarrier.Cast<JsonObject>().ToArray())
            {
                IPoint location = Conversion.ToGeometry(jo, esriGeometryType.esriGeometryPoint) as IPoint;
                edgeBarrier.Add(location);
            }
            traceutils.initlistJunctionFlags(junctionFlags, (double)tol);
            traceutils.initlistEdgeFlags(edgeFlags, (double)tol);
            traceutils.initlistJunctionBarrierEIDs(junctionBarrier, (double)tol);
            traceutils.initlistEdgeBarrierEIDs(edgeBarrier, (double)tol);
            JsonObject trace;
            object[] weight;
            traceutils.solve((int)type, out trace, out weight);
            JsonObject result = new JsonObject();
            result.AddArray("weight", weight);
            result.AddJsonObject("trace", trace);
            //Conversion.ToJsonObject(
            //result.AddJsonObject
            return Encoding.UTF8.GetBytes(result.ToJson());
        }
        private IMapServer3 GetMapServer()
        {
            IMapServer3 mapServer = this.serverObjectHelper.ServerObject as IMapServer3;
            if (mapServer == null)
            {
                throw new Exception("Unable to access the map server.");
            }

            return mapServer;
        }
        
    }
}
