﻿using ESRI.ArcGIS.Geodatabase;
using ESRI.ArcGIS.Geometry;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using ESRI.ArcGIS.NetworkAnalysis;
using ESRI.ArcGIS.Carto;
using ESRI.ArcGIS.Server;
using ESRI.ArcGIS.SOESupport;
namespace TraceAnalyse
{
    class TraceUtils
    {
        private IGeometricNetwork geometricNetwork;
        private ITraceFlowSolverGEN traceFlowSolverGEN;
        private INetSolver netSolver;
        private List<IJunctionFlag> listJunctionFlags;
        private List<IEdgeFlag> listEdgeFlags;
        private List<int> listJunctionBarrierEIDs;
        private List<int> listEdgeBarrierEIDs;
        string[] OutFields;
        private IServerObjectHelper serverObjectHelper;
        public TraceUtils(IGeometricNetwork geometricNetwork, IServerObjectHelper serverObjectHelper)
        {
            this.serverObjectHelper = serverObjectHelper;
            this.geometricNetwork = geometricNetwork;
        }
        public void init()
        {
            traceFlowSolverGEN = new TraceFlowSolverClass();
            netSolver = traceFlowSolverGEN as INetSolver;
            netSolver.SourceNetwork = geometricNetwork.Network;
            listJunctionFlags = new List<IJunctionFlag>();
            listEdgeFlags = new List<IEdgeFlag>();
            listJunctionBarrierEIDs = new List<int>();
            listEdgeBarrierEIDs = new List<int>();
            this.OutFields = new string[] { "*" };
        }
        private IMapServer3 GetMapServer()
        {
            IMapServer3 mapServer = this.serverObjectHelper.ServerObject as IMapServer3;
            if (mapServer == null)
            {
                throw new Exception("Unable to access the map server.");
            }

            return mapServer;
        }
        private IFeatureClass GetFeatureClass(int layerId)
        {
            IMapServer3 mapServer = this.GetMapServer();
            IMapServerDataAccess dataAccess = (IMapServerDataAccess)mapServer;
            return (IFeatureClass)dataAccess.GetDataSource(mapServer.DefaultMapName, layerId);
        }
        private IFeatureClass GetFeatureClassByUserID(int userClassID)
        {
            IMapServer3 serverObject = this.GetMapServer();
            IMapLayerInfos mapLayerInfos = serverObject.GetServerInfo(serverObject.DefaultMapName).MapLayerInfos;

            for (int i = 0; i < mapLayerInfos.Count; i++)
            {
                IMapLayerInfo mapLayerInfo = mapLayerInfos.get_Element(i);
                if (mapLayerInfo.IsFeatureLayer)
                {
                    IFeatureClass featureClass = this.GetFeatureClass(mapLayerInfo.ID);
                    if (featureClass.FeatureClassID == userClassID)
                        return featureClass;
                }
            }
            return null;
        }
        public void initlistJunctionFlags(List<IPoint> points,double tol)
        {

            int eid;
            IGeometry geo;
            for (int i = 0; i < points.Count; i++)
            {
                GetEIDFromPoint(tol, points[i], esriElementType.esriETJunction, this.geometricNetwork, out eid, out geo);
                if (geo != null)
                {
                    INetElements netElements = geometricNetwork.Network as INetElements;
                    int userClassID = 0;
                    int userID = 0;
                    int userSubID = 0;
                    netElements.QueryIDs(eid, esriElementType.esriETJunction, out userClassID, out userID, out userSubID);
                    INetFlag junctionFlag = new JunctionFlagClass() as INetFlag;
                    junctionFlag.UserClassID = userClassID;
                    junctionFlag.UserID = userID;
                    listJunctionFlags.Add(junctionFlag as IJunctionFlag);
                }

            }


        }
        public void initlistEdgeFlags(List<IPoint> points, double tol)
        {

            int eid;
            IGeometry geo;
            for (int i = 0; i < points.Count; i++)
            {
                GetEIDFromPoint(tol, points[i], esriElementType.esriETEdge, this.geometricNetwork, out eid, out geo);
                if (geo != null)
                {
                    INetElements netElements = geometricNetwork.Network as INetElements;
                    int userClassID = 0;
                    int userID = 0;
                    int userSubID = 0;
                    netElements.QueryIDs(eid, esriElementType.esriETEdge, out userClassID, out userID, out userSubID);
                    INetFlag edgeFlag = new EdgeFlagClass() as INetFlag;
                    edgeFlag.UserClassID = userClassID;
                    edgeFlag.UserID = userID;
                    listEdgeFlags.Add(edgeFlag as IEdgeFlag);
                }
            }
        }
        public void initlistJunctionBarrierEIDs(List<IPoint> points, double tol)
        {

            int eid;
            IGeometry geo;
            for (int i = 0; i < points.Count; i++)
            {
                GetEIDFromPoint(tol, points[i], esriElementType.esriETJunction, this.geometricNetwork, out eid, out geo);
                if (geo != null)
                {
                    listJunctionBarrierEIDs.Add(eid);
                }
            }
        }
        public void initlistEdgeBarrierEIDs(List<IPoint> points, double tol)
        {

            int eid;
            IGeometry geo;
            for (int i = 0; i < points.Count; i++)
            {
                GetEIDFromPoint(tol, points[i], esriElementType.esriETEdge, this.geometricNetwork, out eid, out geo);
                if (geo != null)
                {
                    listEdgeBarrierEIDs.Add(eid);
                }
            }
        }
        public void solve(int type, out JsonObject result ,out object[] weight)
        {
            //为追踪任务解决器设置进行分析的管点
            weight = null;
            IJunctionFlag[] arrayJunctionFlag = new IJunctionFlag[listJunctionFlags.Count];
            for (int i = 0; i < listJunctionFlags.Count; i++)
                arrayJunctionFlag[i] = listJunctionFlags[i];
            traceFlowSolverGEN.PutJunctionOrigins(ref arrayJunctionFlag);
            //为追踪任务解决器设置进行分析的管线
            IEdgeFlag[] arrayEdgeFlag = new IEdgeFlag[listEdgeFlags.Count];
            for (int j = 0; j < listEdgeFlags.Count; j++)
                arrayEdgeFlag[j] = listEdgeFlags[j];
            traceFlowSolverGEN.PutEdgeOrigins(ref arrayEdgeFlag);
            //为追踪任务解决器设置进行分析的管点障碍或管线障碍
            INetElementBarriersGEN netElementBarriersGEN = new NetElementBarriersClass();
            netElementBarriersGEN.Network = geometricNetwork.Network;
            //如果目前有管点障碍，则加入分析器中
            if (listJunctionBarrierEIDs.Count > 0)
            {
                int[] junctionBarrierEIDs = new int[listJunctionBarrierEIDs.Count];
                for (int u = 0; u < junctionBarrierEIDs.Length; u++)
                    junctionBarrierEIDs[u] = listJunctionBarrierEIDs[u];
                netElementBarriersGEN.ElementType = esriElementType.esriETJunction;
                netElementBarriersGEN.SetBarriersByEID(ref junctionBarrierEIDs);
                netSolver.set_ElementBarriers(esriElementType.esriETJunction, netElementBarriersGEN as INetElementBarriers);
            }
            //否则将管点障碍设置为空
            else
                netSolver.set_ElementBarriers(esriElementType.esriETJunction, null);
            //如果目前有管线障碍，则加入分析器中
            if (listEdgeBarrierEIDs.Count > 0)
            {
                int[] edgeBarrierEIDs = new int[listEdgeBarrierEIDs.Count];
                for (int u = 0; u < edgeBarrierEIDs.Length; u++)
                    edgeBarrierEIDs[u] = listEdgeBarrierEIDs[u];
                netElementBarriersGEN.ElementType = esriElementType.esriETEdge;
                netElementBarriersGEN.SetBarriersByEID(ref edgeBarrierEIDs);
                netSolver.set_ElementBarriers(esriElementType.esriETEdge, netElementBarriersGEN as INetElementBarriers);
            }
            //否则将管线障碍设置为空
            else
                netSolver.set_ElementBarriers(esriElementType.esriETEdge, null);
            //定义相关变量
            IEnumNetEID junctionEIDs = new EnumNetEIDArrayClass();
            IEnumNetEID edgeEIDs = new EnumNetEIDArrayClass();
            int count = -1;
            object[] segmentCosts = null;
            object pTotalCost = null;
            switch (type)
            {
                //查找共同祖先
                case 1:
                    traceFlowSolverGEN.FindCommonAncestors(esriFlowElements.esriFEJunctionsAndEdges,
                        out junctionEIDs, out edgeEIDs);

                    break;
                //查找相连接的网络要素
                case 2:
                    traceFlowSolverGEN.FindFlowElements(esriFlowMethod.esriFMConnected, esriFlowElements.esriFEJunctionsAndEdges,
                        out junctionEIDs, out edgeEIDs);

                    break;
                //查找网络中的环
                case 3:
                    traceFlowSolverGEN.FindCircuits(esriFlowElements.esriFEJunctionsAndEdges, out junctionEIDs, out edgeEIDs);

                    break;
                //查找未连接的网络要素
                case 4:
                    traceFlowSolverGEN.FindFlowUnreachedElements(esriFlowMethod.esriFMConnected, esriFlowElements.esriFEJunctionsAndEdges,
                        out junctionEIDs, out edgeEIDs);
                    break;
                //查找上游路径。同时获取网络追踪的耗费。
                case 5:
                    count = GetSegmentCounts();
                    weight = new object[count];
                    traceFlowSolverGEN.FindSource(esriFlowMethod.esriFMUpstream, esriShortestPathObjFn.esriSPObjFnMinSum,
                        out junctionEIDs, out edgeEIDs, count, ref weight);
                    break;
                //查找路径。同时获取网络追踪的耗费。count比所有标识的总数少1个。当同时存在JunctionFlag和EdgeFlag时，该功能不可用。
                case 6:
                    if (listJunctionFlags.Count > 0 && listEdgeFlags.Count > 0)
                        break;
                    else if (listJunctionFlags.Count > 0)
                        count = listJunctionFlags.Count - 1;
                    else if (listEdgeFlags.Count > 0)
                        count = listEdgeFlags.Count - 1;
                    else
                        break;
                    weight = new object[count];
                    traceFlowSolverGEN.FindPath(esriFlowMethod.esriFMConnected, esriShortestPathObjFn.esriSPObjFnMinSum,
                        out junctionEIDs, out edgeEIDs, count, ref weight);
                    break;
                //查找上游路径累积消耗。同时获取网络追踪的耗费。
                case 7:
                    pTotalCost = new object();
                    traceFlowSolverGEN.FindAccumulation(esriFlowMethod.esriFMUpstream, esriFlowElements.esriFEJunctionsAndEdges,
                        out junctionEIDs, out edgeEIDs, out pTotalCost);
                    break;
                //上游追踪。
                case 8:
                    count = GetSegmentCounts();
                    segmentCosts = new object[count];
                    traceFlowSolverGEN.FindSource(esriFlowMethod.esriFMUpstream, esriShortestPathObjFn.esriSPObjFnMinSum,
                        out junctionEIDs, out edgeEIDs, count, ref segmentCosts);
                    break;
            }
            this.SetResults(out result, edgeEIDs, junctionEIDs);
        }
        protected void SetResults(out JsonObject objectJson, IEnumNetEID edgeEIDs, IEnumNetEID junctionEIDs)
        {
                INetElements netElements = geometricNetwork.Network as INetElements;
                int userClassID = -1;
                int userID = -1;
                int userSubID = -1;
                int eid = -1;
                IFeature feature;
                IFeatureClass featureClass = null;
                objectJson = new JsonObject();
                if (edgeEIDs.Count == 0)
                {
                    objectJson.AddArray("edges", (new List<JsonObject>()).ToArray());
                }
                else
                {
                    JsonObject[] featureSet = new JsonObject[edgeEIDs.Count];
                    for (int i = 0; i < edgeEIDs.Count; i++)
                    {
                            eid = edgeEIDs.Next();
                            netElements.QueryIDs(eid, esriElementType.esriETEdge, out userClassID, out userID, out userSubID);
                            //需要修改的地方
                            featureClass = GetFeatureClassByUserID(userClassID);
                            if (featureClass != null)
                            {
                                feature = featureClass.GetFeature(userID);
                                featureSet[i] = new JsonObject();
                                featureSet[i].AddJsonObject("geometry", Conversion.ToJsonObject(feature.Shape));
                                JsonObject[] arr = new JsonObject[feature.Fields.FieldCount];
                                for (int j = 0; j < feature.Fields.FieldCount; j++)
                                {
                                    IField field=feature.Fields.Field[j];
                                    arr[j] = new JsonObject();
                                    arr[j].AddObject(field.AliasName, feature.get_Value(j));
                                }
                                featureSet[i].AddArray("attr",arr);

                           }
                    }
                    objectJson.AddArray("edges", featureSet);
                }
               if (junctionEIDs.Count == 0)
                {
                    objectJson.AddArray("junctions", (new List<JsonObject>()).ToArray());
                }
                else
                {
                    JsonObject[] featureSet = new JsonObject[junctionEIDs.Count];
                    for (int i = 0; i < junctionEIDs.Count; i++)
                    {
                        eid = junctionEIDs.Next();
                        netElements.QueryIDs(eid, esriElementType.esriETJunction, out userClassID, out userID, out userSubID);
                        //需要修改的地方
                        featureClass = GetFeatureClassByUserID(userClassID);
                        if (featureClass != null)
                        {
                            feature = featureClass.GetFeature(userID);
                            featureSet[i] = new JsonObject();
                            featureSet[i].AddJsonObject("geometry", Conversion.ToJsonObject(feature.Shape));
                            JsonObject[] arr = new JsonObject[feature.Fields.FieldCount];
                            for (int j = 0; j < feature.Fields.FieldCount; j++)
                            {
                                IField field = feature.Fields.Field[j];
                                arr[j] = new JsonObject();
                                arr[j].AddObject(field.AliasName, feature.get_Value(j));
                            }
                            featureSet[i].AddArray("attr", arr);

                        }
                    }
                    objectJson.AddArray("junctions", featureSet);
                }
            
        }
        
       
        private int GetSegmentCounts()
        {
            int counts = 0;
            if (listJunctionFlags.Count > 0 && listEdgeFlags.Count > 0)
            {
                counts = listJunctionFlags.Count + listEdgeFlags.Count;
            }
            else if (listJunctionFlags.Count > 0)
            {
                counts = listJunctionFlags.Count;
            }
            else if (listEdgeFlags.Count > 0)
            {
                counts = listEdgeFlags.Count;
            }
            return counts;
        }
        
        private IFeatureClass GetFeatureClassByID(int userClassID, IMap map)
        {
            IFeatureClass featureClass = null;
            for (int i = 0; i < map.LayerCount; i++)
            {
                featureClass = ((IFeatureLayer)map.get_Layer(i)).FeatureClass;
                if (featureClass.FeatureClassID == userClassID)
                    return featureClass;
            }
            return null;
        }
        public void GetEIDFromPoint(double searchTolerance, IPoint point, esriElementType elementType, IGeometricNetwork geometricNetwork, out int EID, out IGeometry geometry)
        {
            EID = -1;
            geometry = null;
            IEnumFeatureClass enumFeatureClassSimple = null;
            IEnumFeatureClass enumFeatureClassComlex = null;
            if (elementType == esriElementType.esriETEdge)
            {
                enumFeatureClassSimple = geometricNetwork.get_ClassesByType(esriFeatureType.esriFTSimpleEdge);
                enumFeatureClassComlex = geometricNetwork.get_ClassesByType(esriFeatureType.esriFTComplexEdge);
            }
            else if (elementType == esriElementType.esriETJunction)
            {
                enumFeatureClassSimple = geometricNetwork.get_ClassesByType(esriFeatureType.esriFTSimpleJunction);
                enumFeatureClassComlex = geometricNetwork.get_ClassesByType(esriFeatureType.esriFTComplexJunction);
            }
            double distance = double.PositiveInfinity;
            int featureClassID = -1;
            FindNearestDistance(enumFeatureClassSimple, point, searchTolerance, ref distance, ref featureClassID, ref geometry);
            FindNearestDistance(enumFeatureClassComlex, point, searchTolerance, ref distance, ref featureClassID, ref geometry);
            if (featureClassID == -1)
            {
                EID = -1;
                return;
            }
            IProximityOperator proximityPoint = geometry as IProximityOperator;
            IPoint p = proximityPoint.ReturnNearestPoint(point, esriSegmentExtension.esriNoExtension);
            if (elementType == esriElementType.esriETEdge)
            {
                EID = geometricNetwork.get_EdgeElement(p);
                return;
            }
            else if (elementType == esriElementType.esriETJunction)
            {
                EID = geometricNetwork.get_JunctionElement(p);
                return;
            }

            return;
        }
        private void FindNearestDistance(IEnumFeatureClass enumFeatureClass, IPoint point, double searchTolerance, ref double distance, ref int featureClassID, ref IGeometry featureGeometry)
        {
            enumFeatureClass.Reset();
            IFeatureClass featureClass = enumFeatureClass.Next();
            while (featureClass != null)
            {
                string shapeFieldName = featureClass.ShapeFieldName;
                ITopologicalOperator topologicalOperator = point as ITopologicalOperator;
                ISpatialFilter spatialFilter = new SpatialFilterClass();
                spatialFilter.Geometry = topologicalOperator.Buffer(searchTolerance);
                spatialFilter.SpatialRel = esriSpatialRelEnum.esriSpatialRelIntersects;
                spatialFilter.GeometryField = shapeFieldName;

                IFeatureCursor featureCursor = featureClass.Search(spatialFilter, true);
                IFeature feature = featureCursor.NextFeature();
                while (feature != null)
                {
                   IProximityOperator proximityOperator = feature.ShapeCopy as IProximityOperator;
                   double distanceCurrent = proximityOperator.ReturnDistance(point);
                   if (distance > distanceCurrent)
                   {
                     distance = distanceCurrent;
                     featureClassID = featureClass.FeatureClassID;
                     featureGeometry = feature.ShapeCopy;
                   }

                   feature = featureCursor.NextFeature();
                }             
                featureClass = enumFeatureClass.Next();
            }
        }
    }
}
